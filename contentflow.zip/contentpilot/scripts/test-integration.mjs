// Integration tests for the coin wallet and data isolation.
// Run against a TEST Supabase project (never production):
//   1. Run supabase/migrations/001_init.sql in that project
//   2. Export NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY
//   3. npm run test:integration
import assert from "node:assert/strict";
import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const service = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !anon || !service) {
  console.error("Missing NEXT_PUBLIC_SUPABASE_URL, NEXT_PUBLIC_SUPABASE_ANON_KEY or SUPABASE_SERVICE_ROLE_KEY.");
  process.exit(2);
}

const opts = { auth: { persistSession: false, autoRefreshToken: false } };
const admin = createClient(url, service, opts);
const stamp = Date.now();
const password = `Test-${stamp}-pw!`;
const results = [];
const created = [];

async function test(name, fn) {
  try {
    await fn();
    results.push([name, true]);
    console.log(`  PASS  ${name}`);
  } catch (e) {
    results.push([name, false]);
    console.log(`  FAIL  ${name}\n        ${e.message}`);
  }
}

async function makeUser(label) {
  const email = `cp-test-${label}-${stamp}@example.com`;
  const { data, error } = await admin.auth.admin.createUser({ email, password, email_confirm: true });
  if (error) throw error;
  created.push(data.user.id);
  const client = createClient(url, anon, opts);
  const { error: signErr } = await client.auth.signInWithPassword({ email, password });
  if (signErr) throw signErr;
  return { id: data.user.id, client };
}

const wallet = async (id) => (await admin.rpc("refresh_wallet", { p_user: id })).data;

try {
  const A = await makeUser("a");
  const B = await makeUser("b");
  console.log("\nContentFlow integration tests\n");

  await test("new user gets the Free plan monthly allowance (100 coins)", async () => {
    const w = await wallet(A.id);
    assert.equal(w.plan_id, "free");
    assert.equal(w.total, 100);
  });

  await test("browser clients cannot call wallet functions", async () => {
    for (const [fn, args] of [
      ["spend_coins", { p_user: A.id, p_cost: 1, p_key: `x-${stamp}`, p_tool: "caption" }],
      ["grant_coins", { p_user: A.id, p_amount: 999, p_bucket: "purchased", p_reason: "hack", p_key: null, p_meta: {}, p_actor: null }],
      ["refresh_wallet", { p_user: A.id }],
    ]) {
      const { error } = await A.client.rpc(fn, args);
      assert.ok(error, `${fn} should be denied to authenticated users`);
    }
    assert.equal((await wallet(A.id)).total, 100);
  });

  await test("a user cannot modify their own wallet, ledger or subscription", async () => {
    await A.client.from("wallets").update({ purchased_coins: 100000 }).eq("user_id", A.id);
    await A.client.from("subscriptions").update({ plan: "business", status: "active" }).eq("user_id", A.id);
    await A.client.from("coin_ledger").insert({ user_id: A.id, delta: 1000, bucket: "x", reason: "x", balance_after: 1000 });
    const w = await wallet(A.id);
    assert.equal(w.purchased_coins, 0);
    const { data: sub } = await admin.from("subscriptions").select("plan,status").eq("user_id", A.id).single();
    assert.equal(sub.plan, "free");
  });

  await test("a user cannot make themselves admin", async () => {
    await A.client.from("profiles").update({ role: "admin" }).eq("id", A.id);
    const { data } = await admin.from("profiles").select("role").eq("id", A.id).single();
    assert.equal(data.role, "user");
  });

  await test("data isolation: B cannot read A's generations, ledger, wallet, brands, calendar", async () => {
    await admin.from("generations").insert({ user_id: A.id, tool: "caption", text: "secret A", title: "A" });
    await admin.from("brands").insert({ user_id: A.id, name: "A brand" });
    await admin.from("calendar_entries").insert({ user_id: A.id, date: "2030-01-01", platform: "Instagram", topic: "A topic" });
    for (const table of ["generations", "coin_ledger", "wallets", "brands", "calendar_entries", "subscriptions", "payments"]) {
      const { data } = await B.client.from(table).select("*");
      assert.ok(!(data ?? []).some((r) => r.user_id === A.id), `${table}: B can see A's rows`);
    }
    const { data: own } = await A.client.from("generations").select("id");
    assert.equal(own.length, 1, "A should see their own row");
  });

  await test("B cannot update or delete A's rows", async () => {
    await B.client.from("generations").update({ text: "hacked" }).eq("user_id", A.id);
    await B.client.from("generations").delete().eq("user_id", A.id);
    const { data } = await admin.from("generations").select("text").eq("user_id", A.id);
    assert.equal(data.length, 1);
    assert.equal(data[0].text, "secret A");
  });

  await test("spending is atomic: 30 parallel spends of 5 on 100 coins => exactly 20 succeed, never negative", async () => {
    const runs = await Promise.all(
      Array.from({ length: 30 }, (_, i) => admin.rpc("spend_coins", { p_user: A.id, p_cost: 5, p_key: `par-${stamp}-${i}`, p_tool: "caption" })),
    );
    const ok = runs.filter((r) => r.data?.ok).length;
    const no = runs.filter((r) => r.data && !r.data.ok && r.data.reason === "insufficient").length;
    assert.equal(ok, 20);
    assert.equal(no, 10);
    assert.equal((await wallet(A.id)).total, 0);
  });

  await test("spend is idempotent per key (no double charge)", async () => {
    await admin.rpc("grant_coins", { p_user: B.id, p_amount: 50, p_bucket: "purchased", p_reason: "test", p_key: `g-${stamp}`, p_meta: {}, p_actor: null });
    const before = (await wallet(B.id)).total; // 100 plan + 50
    const key = `idem-${stamp}`;
    const r1 = await admin.rpc("spend_coins", { p_user: B.id, p_cost: 10, p_key: key, p_tool: "caption" });
    const r2 = await admin.rpc("spend_coins", { p_user: B.id, p_cost: 10, p_key: key, p_tool: "caption" });
    assert.equal(r1.data.ok, true);
    assert.equal(r2.data.duplicate, true);
    assert.equal((await wallet(B.id)).total, before - 10);
  });

  await test("plan coins are spent before purchased coins", async () => {
    const before = await wallet(B.id); // plan 90, purchased 50 after previous test
    await admin.rpc("spend_coins", { p_user: B.id, p_cost: 20, p_key: `order-${stamp}`, p_tool: "caption" });
    const after = await wallet(B.id);
    assert.equal(after.plan_coins, before.plan_coins - 20);
    assert.equal(after.purchased_coins, before.purchased_coins);
  });

  await test("refund restores the exact buckets and is idempotent", async () => {
    const key = `ref-${stamp}`;
    const before = await wallet(B.id);
    await admin.rpc("spend_coins", { p_user: B.id, p_cost: before.plan_coins + 5, p_key: key, p_tool: "blog" }); // spills into purchased
    const mid = await wallet(B.id);
    assert.equal(mid.plan_coins, 0);
    assert.equal(mid.purchased_coins, before.purchased_coins - 5);
    await admin.rpc("refund_coins", { p_user: B.id, p_key: key });
    const r2 = await admin.rpc("refund_coins", { p_user: B.id, p_key: key });
    assert.equal(r2.data.duplicate, true);
    const after = await wallet(B.id);
    assert.equal(after.plan_coins, before.plan_coins);
    assert.equal(after.purchased_coins, before.purchased_coins);
  });

  await test("grant (purchase credit) is idempotent per payment reference", async () => {
    const before = (await wallet(B.id)).total;
    for (let i = 0; i < 3; i++) {
      await admin.rpc("grant_coins", { p_user: B.id, p_amount: 500, p_bucket: "purchased", p_reason: "purchase", p_key: `session:test-${stamp}`, p_meta: {}, p_actor: null });
    }
    assert.equal((await wallet(B.id)).total, before + 500);
  });

  await test("negative admin adjustment cannot push the balance below zero", async () => {
    const { error } = await admin.rpc("grant_coins", { p_user: A.id, p_amount: -999999, p_bucket: "purchased", p_reason: "admin_adjustment", p_key: null, p_meta: {}, p_actor: null });
    assert.ok(error, "expected a constraint error");
    assert.ok((await wallet(A.id)).total >= 0);
  });

  await test("every balance change is in the ledger and balances reconcile", async () => {
    const { data: rows } = await admin.from("coin_ledger").select("delta").eq("user_id", B.id);
    const sum = rows.reduce((s, r) => s + r.delta, 0);
    assert.equal(sum, (await wallet(B.id)).total);
  });

  await test("evolution tables: B cannot read A's posts, strategy or feedback; browsers cannot write; tokens are unreadable", async () => {
    await admin.from("posts").insert({ user_id: A.id, platform: "instagram", title: "A post", published_at: "2030-01-01", views: 10 });
    await admin.from("strategy_profiles").insert({ user_id: A.id, goal: "views" });
    await admin.from("recommendation_feedback").insert({ user_id: A.id, finding_id: "x", status: "accepted" });
    await admin.from("social_connections").insert({ user_id: A.id, provider: "tiktok", access_token_enc: "v1:SECRET:SECRET:SECRET" });
    for (const table of ["posts", "strategy_profiles", "recommendation_feedback"]) {
      const { data } = await B.client.from(table).select("*");
      assert.ok(!(data ?? []).some((r) => r.user_id === A.id), `${table}: B can see A's rows`);
    }
    const own = await A.client.from("posts").select("id");
    assert.equal(own.data?.length, 1, "A should see their own post");
    // Browser writes must be rejected.
    const ins = await A.client.from("posts").insert({ user_id: A.id, platform: "x", title: "forged", published_at: "2030-01-02", views: 999999 });
    assert.ok(ins.error, "browser insert into posts should fail");
    // Nobody can read social_connections from a browser client, not even the owner.
    for (const c of [A.client, B.client]) {
      const r = await c.from("social_connections").select("*");
      assert.ok(r.error || (r.data ?? []).length === 0, "social_connections must not be readable from the browser");
    }
  });

  await test("paid plan coins are granted and replaced (not accumulated) on plan change", async () => {
    await admin.from("subscriptions").update({ plan: "pro", status: "active", current_period_end: new Date(Date.now() + 30 * 86400000).toISOString() }).eq("user_id", A.id);
    const w = await wallet(A.id);
    assert.equal(w.plan_id, "pro");
    assert.equal(w.plan_coins, 2000);
    await admin.from("subscriptions").update({ status: "canceled" }).eq("user_id", A.id);
    const back = await wallet(A.id);
    assert.equal(back.plan_id, "free");
    assert.equal(back.plan_coins, 100);
  });
} catch (e) {
  console.error("Setup failed:", e.message);
  results.push(["setup", false]);
} finally {
  for (const id of created) await admin.auth.admin.deleteUser(id);
  const failed = results.filter(([, ok]) => !ok).length;
  console.log(`\n${results.length - failed}/${results.length} passed${failed ? `, ${failed} FAILED` : ""}\n`);
  process.exit(failed ? 1 : 0);
}
