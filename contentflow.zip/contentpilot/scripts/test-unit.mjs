// Unit tests that need no database or network: insights engine and token encryption.
// Run: npm run test:unit   (Node >= 22.6; uses built-in TypeScript stripping)
import assert from "node:assert/strict";
import { randomBytes } from "node:crypto";
import { analyze, summarize, MIN_POSTS } from "../src/lib/insights.ts";
import { decryptToken, encryptToken, encryptionConfigured } from "../src/lib/crypto.ts";

let pass = 0;
let fail = 0;
function test(name, fn) {
  try {
    fn();
    pass++;
    console.log(`  PASS  ${name}`);
  } catch (e) {
    fail++;
    console.log(`  FAIL  ${name}\n        ${e.message}`);
  }
}

let n = 0;
const post = (o) => ({
  id: `p${++n}`, platform: "TikTok", title: `Post ${n}`, format: "", topic: "", objective: null,
  published_at: "2026-01-01", source: "manual",
  views: null, likes: null, comments: null, shares: null, saves: null, reach: null, ...o,
});

console.log("\nInsights engine\n");

test("no posts: not enough data, no findings, experiments suggested", () => {
  const a = analyze([]);
  assert.equal(a.enough, false);
  assert.equal(a.findings.length, 0);
  assert.ok(a.experiments.length >= 3);
  assert.match(a.limitation.en, /not enough data/i);
});

test(`fewer than ${MIN_POSTS} posts with views: explains the limitation and does not invent patterns`, () => {
  const posts = [1, 2, 3, 4].map((i) => post({ views: 100 * i, format: i % 2 ? "Reel" : "Carousel" }));
  const a = analyze(posts);
  assert.equal(a.enough, false);
  assert.equal(a.findings.length, 0);
  assert.match(a.limitation.en, /4 of the 5/);
});

test("posts without a views value are NOT counted as zero views", () => {
  const posts = [
    ...[1, 2, 3, 4].map((i) => post({ views: 100 * i })),
    post({ views: null, likes: 5 }),
    post({ views: null }),
  ];
  const a = analyze(posts);
  assert.equal(a.summary.postsWithViews, 4);
  assert.equal(a.enough, false);
});

test("format finding: reports the real averages and counts from the data", () => {
  const posts = [
    post({ format: "Reel", views: 1000, title: "Demo A" }),
    post({ format: "Reel", views: 3000, title: "Demo B" }),
    post({ format: "Carousel", views: 300 }),
    post({ format: "Carousel", views: 500 }),
    post({ format: "Text", views: 400 }),
    post({ format: "Text", views: 200 }),
  ];
  const a = analyze(posts);
  assert.equal(a.enough, true);
  const f = a.findings.find((x) => x.kind === "format_views");
  assert.ok(f, "expected a format finding");
  assert.match(f.evidence[0].en, /average 2000 views across 2 posts/); // (1000+3000)/2
  assert.match(f.evidence[1].en, /average 350 views across 4 posts/); // (300+500+400+200)/4
  assert.equal(f.generate.tool, "script"); // Reel -> script tool
  assert.equal(f.confidence, "low"); // only 2 posts in the best group: never overstated
});

test("no format finding when formats perform about the same", () => {
  const posts = [
    post({ format: "Reel", views: 500 }), post({ format: "Reel", views: 520 }),
    post({ format: "Carousel", views: 510 }), post({ format: "Carousel", views: 490 }), post({ format: "Text", views: 505 }),
  ];
  const a = analyze(posts);
  assert.equal(a.findings.some((x) => x.kind === "format_views"), false);
});

test("topic finding: more comments on one topic, with correct averages", () => {
  const posts = [
    post({ topic: "Pricing", views: 500, comments: 20 }), post({ topic: "Pricing", views: 400, comments: 30 }),
    post({ topic: "Behind the scenes", views: 500, comments: 2 }), post({ topic: "Behind the scenes", views: 450, comments: 4 }),
    post({ topic: "Tips", views: 480, comments: 3 }),
  ];
  const f = analyze(posts).findings.find((x) => x.kind === "topic_comments");
  assert.ok(f);
  assert.match(f.evidence[0].en, /average 25\.0 comments across 2 posts/);
  assert.equal(f.generate.topic, "Pricing");
});

test("views-but-low-engagement: flags a high-view, low-interaction post", () => {
  const posts = [
    post({ title: "Viral but quiet", views: 10000, likes: 20, comments: 1 }),
    post({ views: 1000, likes: 150, comments: 20 }),
    post({ views: 1200, likes: 180, comments: 25 }),
    post({ views: 900, likes: 120, comments: 18 }),
    post({ views: 1100, likes: 160, comments: 22 }),
  ];
  const f = analyze(posts).findings.find((x) => x.kind === "views_low_engagement");
  assert.ok(f);
  assert.match(f.text.en, /Viral but quiet/);
  assert.match(f.evidence[0].en, /10000 views, 21 interactions/);
  assert.equal(f.generate.tool, "titles");
});

test("top post is reported factually", () => {
  const posts = [1, 2, 3, 4, 5].map((i) => post({ views: i * 100, title: `T${i}` }));
  const f = analyze(posts).findings.find((x) => x.kind === "top_post");
  assert.ok(f);
  assert.match(f.text.en, /T5/);
  assert.match(f.evidence[0].en, /500 views/);
});

test("every finding has evidence, an action and a generate target (and PT text)", () => {
  const posts = [
    post({ format: "Reel", topic: "A", views: 2000, comments: 30, likes: 100 }), post({ format: "Reel", topic: "A", views: 2500, comments: 40, likes: 120 }),
    post({ format: "Post", topic: "B", views: 300, comments: 2, likes: 10 }), post({ format: "Post", topic: "B", views: 400, comments: 3, likes: 12 }),
    post({ format: "Post", topic: "C", views: 350, comments: 1, likes: 9 }),
  ];
  const a = analyze(posts);
  assert.ok(a.findings.length > 0);
  for (const f of a.findings) {
    assert.ok(f.evidence.length >= 1 && f.evidence.every((e) => e.en && e.pt));
    assert.ok(f.action.en && f.action.pt && f.text.en && f.text.pt);
    assert.ok(f.generate.tool);
    assert.ok(["low", "medium"].includes(f.confidence)); // never "high": no certainty claimed
  }
});

test("summary totals count only values that exist and separate manual vs synced", () => {
  const s = summarize([
    post({ views: 100, likes: 10, source: "manual" }),
    post({ views: 50, comments: 5, source: "synced" }),
    post({ source: "manual" }),
  ]);
  assert.equal(s.totals.views, 150);
  assert.equal(s.totals.likes, 10);
  assert.equal(s.totals.comments, 5);
  assert.equal(s.manualPosts, 2);
  assert.equal(s.syncedPosts, 1);
  assert.equal(s.postsWithViews, 2);
});

console.log("\nToken encryption\n");

process.env.TOKEN_ENCRYPTION_KEY = randomBytes(32).toString("base64");

test("encrypt/decrypt round trip", () => {
  assert.equal(encryptionConfigured(), true);
  const secret = "act.example-access-token-123";
  const enc = encryptToken(secret);
  assert.ok(!enc.includes(secret), "ciphertext must not contain the plaintext");
  assert.equal(decryptToken(enc), secret);
});

test("same input encrypts differently each time (random IV)", () => {
  assert.notEqual(encryptToken("abc"), encryptToken("abc"));
});

test("tampered ciphertext is rejected", () => {
  const parts = encryptToken("abc").split(":");
  const data = Buffer.from(parts[3], "base64");
  data[0] ^= 1;
  parts[3] = data.toString("base64");
  assert.throws(() => decryptToken(parts.join(":")));
});

test("a different key cannot decrypt", () => {
  const enc = encryptToken("abc");
  process.env.TOKEN_ENCRYPTION_KEY = randomBytes(32).toString("base64");
  assert.throws(() => decryptToken(enc));
});

test("missing or malformed key is reported, not silently accepted", () => {
  delete process.env.TOKEN_ENCRYPTION_KEY;
  assert.equal(encryptionConfigured(), false);
  assert.throws(() => encryptToken("abc"), /TOKEN_ENCRYPTION_KEY/);
  process.env.TOKEN_ENCRYPTION_KEY = Buffer.from("too short").toString("base64");
  assert.equal(encryptionConfigured(), false);
});

console.log(`\n${pass}/${pass + fail} passed${fail ? `, ${fail} FAILED` : ""}\n`);
process.exit(fail ? 1 : 0);
