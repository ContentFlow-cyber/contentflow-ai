-- ContentFlow AI — strategy evolution (goals, results tracking, recommendations, social connections).
-- ADDITIVE: run AFTER 001_init.sql. Does not modify or remove anything that already exists.

-- ================================================================ goal / business profile
create table if not exists public.strategy_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  goal text check (goal in ('views','followers','engagement','leads','sales','promote')),
  business_type text not null default '',
  audience text not null default '',
  platform text,
  updated_at timestamptz not null default now()
);

-- ================================================================ published posts + results
-- Metrics are NULLABLE on purpose: a missing metric stays empty, it is never invented.
create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  generation_id uuid references public.generations(id) on delete set null,
  platform text not null,
  title text not null,
  format text not null default '',
  topic text not null default '',
  objective text check (objective in ('views','followers','engagement','leads','sales','promote')),
  published_at date not null,
  url text,
  source text not null default 'manual' check (source in ('manual','synced')),
  external_id text,
  views bigint check (views >= 0),
  likes bigint check (likes >= 0),
  comments bigint check (comments >= 0),
  shares bigint check (shares >= 0),
  saves bigint check (saves >= 0),
  reach bigint check (reach >= 0),
  last_synced_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, platform, external_id)   -- NULL external_id (manual posts) never conflicts
);
create index if not exists posts_user_date_idx on public.posts (user_id, published_at desc);

-- ================================================================ AI suggestion decisions
create table if not exists public.recommendation_feedback (
  user_id uuid not null references auth.users(id) on delete cascade,
  finding_id text not null,
  status text not null check (status in ('accepted','rejected','skipped')),
  updated_at timestamptz not null default now(),
  primary key (user_id, finding_id)
);

-- ================================================================ social connections
-- Tokens are AES-256-GCM encrypted by the server before storage and are NEVER readable
-- from the browser: RLS is on with no policies and all privileges are revoked below.
create table if not exists public.social_connections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  provider text not null check (provider in ('tiktok','instagram')),
  account_id text,
  username text,
  access_token_enc text not null,
  refresh_token_enc text,
  expires_at timestamptz,
  refresh_expires_at timestamptz,
  scopes text,
  status text not null default 'connected' check (status in ('connected','expired','error')),
  last_error text,
  last_synced_at timestamptz,
  created_at timestamptz not null default now(),
  unique (user_id, provider)
);

-- ================================================================ RLS and privileges
alter table public.strategy_profiles enable row level security;
alter table public.posts enable row level security;
alter table public.recommendation_feedback enable row level security;
alter table public.social_connections enable row level security;

drop policy if exists "strategy_own" on public.strategy_profiles;
create policy "strategy_own" on public.strategy_profiles for select using (auth.uid() = user_id);
drop policy if exists "posts_own" on public.posts;
create policy "posts_own" on public.posts for select using (auth.uid() = user_id);
drop policy if exists "feedback_own" on public.recommendation_feedback;
create policy "feedback_own" on public.recommendation_feedback for select using (auth.uid() = user_id);
-- social_connections: no policies on purpose.

-- Browser clients are read-only on the new tables; all writes go through server routes.
revoke insert, update, delete, truncate on public.strategy_profiles, public.posts, public.recommendation_feedback from anon, authenticated;
revoke select on public.strategy_profiles, public.posts, public.recommendation_feedback from anon;
revoke all on public.social_connections from anon, authenticated;

-- ================================================================ new tool cost (editable in Admin)
insert into public.tool_costs (tool, coins, enabled, min_plan, sort)
values ('insights', 3, true, 'free', 15)
on conflict (tool) do nothing;
