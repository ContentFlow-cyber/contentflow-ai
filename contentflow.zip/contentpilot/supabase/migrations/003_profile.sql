-- ContentFlow AI — profile fields (nickname, gender, birthday, photo). ADDITIVE: run after 002.
alter table public.profiles add column if not exists nickname text not null default '';
alter table public.profiles add column if not exists gender text check (gender in ('female','male','other','prefer_not'));
alter table public.profiles add column if not exists birthday date;
alter table public.profiles add column if not exists avatar_url text;

-- Profile photos. Public bucket (the photo is shown in the UI); only the server uploads, under <user_id>/.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 2097152, array['image/png','image/jpeg','image/webp'])
on conflict (id) do nothing;
-- No storage policies for browsers: uploads go through the server (service role).
-- The new columns are written only by /api/profile (service role); browser grants stay as in 001.
