-- ContentFlow AI — schema, coin wallet, ledger and Row Level Security.
-- Run once in Supabase: SQL Editor > New query > paste > Run.
-- To make yourself admin afterwards:
--   update public.profiles set role = 'admin' where email = 'you@example.com';

create extension if not exists pgcrypto;

-- ================================================================ tables
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  full_name text not null default '',
  language text not null default 'en',
  currency text not null default 'eur' check (currency in ('eur','usd')),
  role text not null default 'user' check (role in ('user','admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  default_platform text,
  default_tone text,
  default_language text,
  brand_voice text not null default '',
  updated_at timestamptz not null default now()
);

-- Plans are editable by admins. Prices in minor units (cents).
create table if not exists public.plans (
  id text primary key check (id in ('free','pro','business')),
  name text not null,
  monthly_coins int not null check (monthly_coins >= 0),
  price_eur_month int not null default 0,
  price_usd_month int not null default 0,
  price_eur_year int not null default 0,
  price_usd_year int not null default 0,
  history_limit int not null default 0,       -- 0 = unlimited
  max_brands int not null default 0,
  can_favorite boolean not null default false,
  can_export boolean not null default false,
  can_calendar boolean not null default false,
  can_brand_voice boolean not null default false,
  features jsonb not null default '[]'::jsonb, -- [{en, pt, status: live|soon}]
  sort int not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.tool_costs (
  tool text primary key,
  coins int not null check (coins >= 0),
  enabled boolean not null default true,
  min_plan text not null default 'free' check (min_plan in ('free','pro','business')),
  sort int not null default 0
);

create table if not exists public.coin_packages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  coins int not null check (coins > 0),
  price_eur int not null check (price_eur > 0),
  price_usd int not null check (price_usd > 0),
  is_active boolean not null default true,
  sort int not null default 0
);

-- Two buckets: plan_coins (monthly allowance, do NOT roll over) and
-- purchased_coins (bought packs, never expire). Plan coins are spent first.
create table if not exists public.wallets (
  user_id uuid primary key references auth.users(id) on delete cascade,
  plan_id text not null default 'free',
  plan_coins int not null default 0 check (plan_coins >= 0),
  purchased_coins int not null default 0 check (purchased_coins >= 0),
  plan_coins_expire_at timestamptz,
  updated_at timestamptz not null default now()
);

-- Append-only audit trail of every balance change.
create table if not exists public.coin_ledger (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  delta int not null,
  bucket text not null,
  reason text not null,
  balance_after int not null,
  idempotency_key text unique,
  meta jsonb not null default '{}'::jsonb,
  actor uuid,
  created_at timestamptz not null default now()
);
create index if not exists coin_ledger_user_idx on public.coin_ledger (user_id, created_at desc);

create table if not exists public.subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  plan text not null default 'free' check (plan in ('free','pro','business')),
  status text not null default 'inactive',
  interval text not null default 'month' check (interval in ('month','year')),
  currency text,
  stripe_customer_id text unique,
  stripe_subscription_id text unique,
  current_period_end timestamptz,
  cancel_at_period_end boolean not null default false,
  updated_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  kind text not null check (kind in ('subscription','coins')),
  stripe_ref text unique,
  amount int not null default 0,
  currency text,
  coins int not null default 0,
  status text not null default 'paid',
  created_at timestamptz not null default now()
);
create index if not exists payments_user_idx on public.payments (user_id, created_at desc);

create table if not exists public.brands (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  voice text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.generations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  tool text not null,
  brand_id uuid references public.brands(id) on delete set null,
  title text not null default '',
  input jsonb not null default '{}'::jsonb,
  output jsonb not null default '{}'::jsonb,
  text text not null default '',
  is_favorite boolean not null default false,
  coins_spent int not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists generations_user_idx on public.generations (user_id, created_at desc);

create table if not exists public.calendar_entries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  brand_id uuid references public.brands(id) on delete set null,
  date date not null,
  platform text not null,
  topic text not null,
  format text not null default '',
  idea text not null default '',
  status text not null default 'planned' check (status in ('planned','draft','published')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists calendar_user_date_idx on public.calendar_entries (user_id, date);

create table if not exists public.error_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  scope text not null,
  message text not null,
  meta jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.audit_log (
  id uuid primary key default gen_random_uuid(),
  actor uuid,
  action text not null,
  target text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.stripe_events (
  id text primary key,
  type text not null,
  created_at timestamptz not null default now()
);

-- ================================================================ RLS
alter table public.profiles enable row level security;
alter table public.preferences enable row level security;
alter table public.plans enable row level security;
alter table public.tool_costs enable row level security;
alter table public.coin_packages enable row level security;
alter table public.wallets enable row level security;
alter table public.coin_ledger enable row level security;
alter table public.subscriptions enable row level security;
alter table public.payments enable row level security;
alter table public.brands enable row level security;
alter table public.generations enable row level security;
alter table public.calendar_entries enable row level security;
alter table public.error_logs enable row level security;
alter table public.audit_log enable row level security;
alter table public.stripe_events enable row level security;

-- Public catalogue (pricing page)
drop policy if exists "plans_read" on public.plans;
create policy "plans_read" on public.plans for select using (true);
drop policy if exists "tool_costs_read" on public.tool_costs;
create policy "tool_costs_read" on public.tool_costs for select using (true);
drop policy if exists "packages_read" on public.coin_packages;
create policy "packages_read" on public.coin_packages for select using (is_active);

-- Own-row reads
drop policy if exists "profiles_own" on public.profiles;
create policy "profiles_own" on public.profiles for select using (auth.uid() = id);
drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
drop policy if exists "prefs_own" on public.preferences;
create policy "prefs_own" on public.preferences for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "wallet_own" on public.wallets;
create policy "wallet_own" on public.wallets for select using (auth.uid() = user_id);
drop policy if exists "ledger_own" on public.coin_ledger;
create policy "ledger_own" on public.coin_ledger for select using (auth.uid() = user_id);
drop policy if exists "subs_own" on public.subscriptions;
create policy "subs_own" on public.subscriptions for select using (auth.uid() = user_id);
drop policy if exists "payments_own" on public.payments;
create policy "payments_own" on public.payments for select using (auth.uid() = user_id);
drop policy if exists "brands_own" on public.brands;
create policy "brands_own" on public.brands for select using (auth.uid() = user_id);
drop policy if exists "gen_own" on public.generations;
create policy "gen_own" on public.generations for select using (auth.uid() = user_id);
drop policy if exists "cal_own" on public.calendar_entries;
create policy "cal_own" on public.calendar_entries for select using (auth.uid() = user_id);
-- error_logs, audit_log, stripe_events: RLS on, no policies => service role only.

-- Browser clients can only READ, except their own preferences and two profile columns.
-- Every other write goes through server routes that use the service role.
revoke insert, update, delete, truncate on all tables in schema public from anon, authenticated;
grant insert, update, delete on public.preferences to authenticated;
grant update (full_name, language, currency) on public.profiles to authenticated;
revoke all on public.error_logs, public.audit_log, public.stripe_events from anon, authenticated;
revoke select on public.payments, public.coin_ledger, public.wallets from anon;

-- ================================================================ new-user trigger
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', ''))
  on conflict (id) do nothing;
  insert into public.preferences (user_id) values (new.id) on conflict (user_id) do nothing;
  insert into public.wallets (user_id) values (new.id) on conflict (user_id) do nothing;
  insert into public.subscriptions (user_id) values (new.id) on conflict (user_id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ================================================================ wallet functions
-- All functions are SECURITY DEFINER and callable ONLY by the service role, so the
-- browser can never change a balance. Each takes a per-user advisory lock, so
-- parallel requests cannot overspend or double-charge.

-- Brings the wallet up to date: monthly allowance for the effective plan, no rollover.
create or replace function public.refresh_wallet(p_user uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  w public.wallets;
  sub public.subscriptions;
  eff text;
  monthly int;
  newexp timestamptz;
begin
  perform pg_advisory_xact_lock(hashtext(p_user::text));
  insert into public.wallets (user_id) values (p_user) on conflict (user_id) do nothing;
  select * into w from public.wallets where user_id = p_user for update;

  select * into sub from public.subscriptions
   where user_id = p_user and status in ('active','trialing','past_due');
  eff := coalesce(sub.plan, 'free');

  if w.plan_coins_expire_at is null or w.plan_id <> eff or now() >= w.plan_coins_expire_at then
    select monthly_coins into monthly from public.plans where id = eff;
    monthly := coalesce(monthly, 0);

    if sub.user_id is not null and sub.interval = 'month'
       and sub.current_period_end is not null and sub.current_period_end > now() then
      newexp := sub.current_period_end;
    else
      newexp := now() + interval '1 month';
    end if;

    if w.plan_coins > 0 then
      insert into public.coin_ledger (user_id, delta, bucket, reason, balance_after, meta)
      values (p_user, -w.plan_coins, 'plan', 'plan_expiry', w.purchased_coins,
              jsonb_build_object('plan', w.plan_id));
    end if;
    if monthly > 0 then
      insert into public.coin_ledger (user_id, delta, bucket, reason, balance_after, meta)
      values (p_user, monthly, 'plan', 'plan_renewal', w.purchased_coins + monthly,
              jsonb_build_object('plan', eff));
    end if;

    update public.wallets
       set plan_id = eff, plan_coins = monthly, plan_coins_expire_at = newexp, updated_at = now()
     where user_id = p_user;
  end if;

  select * into w from public.wallets where user_id = p_user;
  return jsonb_build_object(
    'plan_id', w.plan_id,
    'plan_coins', w.plan_coins,
    'purchased_coins', w.purchased_coins,
    'total', w.plan_coins + w.purchased_coins,
    'expires_at', w.plan_coins_expire_at
  );
end;
$$;

-- Deducts coins (plan coins first). Idempotent per p_key. Never goes negative.
create or replace function public.spend_coins(p_user uuid, p_cost int, p_key text, p_tool text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  w public.wallets;
  from_plan int;
  from_buy int;
begin
  if p_cost < 0 then raise exception 'negative cost'; end if;
  perform public.refresh_wallet(p_user);

  if exists (select 1 from public.coin_ledger where idempotency_key = p_key) then
    return jsonb_build_object('ok', true, 'duplicate', true);
  end if;

  select * into w from public.wallets where user_id = p_user for update;
  if w.plan_coins + w.purchased_coins < p_cost then
    return jsonb_build_object('ok', false, 'reason', 'insufficient',
                              'balance', w.plan_coins + w.purchased_coins, 'cost', p_cost);
  end if;

  from_plan := least(w.plan_coins, p_cost);
  from_buy := p_cost - from_plan;

  update public.wallets
     set plan_coins = plan_coins - from_plan,
         purchased_coins = purchased_coins - from_buy,
         updated_at = now()
   where user_id = p_user;

  insert into public.coin_ledger (user_id, delta, bucket, reason, balance_after, idempotency_key, meta)
  values (p_user, -p_cost, 'mixed', 'spend:' || p_tool,
          w.plan_coins + w.purchased_coins - p_cost, p_key,
          jsonb_build_object('plan', from_plan, 'purchased', from_buy, 'tool', p_tool));

  return jsonb_build_object('ok', true,
    'balance', w.plan_coins + w.purchased_coins - p_cost,
    'plan_coins', w.plan_coins - from_plan,
    'purchased_coins', w.purchased_coins - from_buy);
end;
$$;

-- Gives back a previous spend (used when generation fails). Idempotent.
create or replace function public.refund_coins(p_user uuid, p_key text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  sp public.coin_ledger;
  fp int;
  fb int;
  bal int;
begin
  perform pg_advisory_xact_lock(hashtext(p_user::text));
  select * into sp from public.coin_ledger where idempotency_key = p_key and user_id = p_user;
  if not found then return jsonb_build_object('ok', false, 'reason', 'not_found'); end if;
  if exists (select 1 from public.coin_ledger where idempotency_key = 'refund:' || p_key) then
    return jsonb_build_object('ok', true, 'duplicate', true);
  end if;

  fp := coalesce((sp.meta->>'plan')::int, 0);
  fb := coalesce((sp.meta->>'purchased')::int, 0);

  update public.wallets
     set plan_coins = plan_coins + fp, purchased_coins = purchased_coins + fb, updated_at = now()
   where user_id = p_user
  returning plan_coins + purchased_coins into bal;

  insert into public.coin_ledger (user_id, delta, bucket, reason, balance_after, idempotency_key, meta)
  values (p_user, fp + fb, 'mixed', 'refund:' || coalesce(sp.meta->>'tool', ''), bal,
          'refund:' || p_key, jsonb_build_object('plan', fp, 'purchased', fb));

  return jsonb_build_object('ok', true, 'balance', bal);
end;
$$;

-- Adds (or, for admin corrections, removes) coins. Idempotent per p_key.
-- p_bucket: 'purchased' (never expires) or 'plan' (expires with the monthly cycle).
create or replace function public.grant_coins(
  p_user uuid, p_amount int, p_bucket text, p_reason text,
  p_key text, p_meta jsonb, p_actor uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  w public.wallets;
begin
  if p_bucket not in ('purchased','plan') then raise exception 'invalid bucket'; end if;
  perform public.refresh_wallet(p_user);

  if p_key is not null and exists (select 1 from public.coin_ledger where idempotency_key = p_key) then
    return jsonb_build_object('ok', true, 'duplicate', true);
  end if;

  update public.wallets
     set plan_coins = plan_coins + case when p_bucket = 'plan' then p_amount else 0 end,
         purchased_coins = purchased_coins + case when p_bucket = 'purchased' then p_amount else 0 end,
         updated_at = now()
   where user_id = p_user
  returning * into w;   -- CHECK constraints reject any result below zero

  insert into public.coin_ledger (user_id, delta, bucket, reason, balance_after, idempotency_key, meta, actor)
  values (p_user, p_amount, p_bucket, p_reason, w.plan_coins + w.purchased_coins,
          p_key, coalesce(p_meta, '{}'::jsonb), p_actor);

  return jsonb_build_object('ok', true, 'balance', w.plan_coins + w.purchased_coins);
end;
$$;

revoke all on function public.refresh_wallet(uuid) from public, anon, authenticated;
revoke all on function public.spend_coins(uuid, int, text, text) from public, anon, authenticated;
revoke all on function public.refund_coins(uuid, text) from public, anon, authenticated;
revoke all on function public.grant_coins(uuid, int, text, text, text, jsonb, uuid) from public, anon, authenticated;
grant execute on function public.refresh_wallet(uuid) to service_role;
grant execute on function public.spend_coins(uuid, int, text, text) to service_role;
grant execute on function public.refund_coins(uuid, text) to service_role;
grant execute on function public.grant_coins(uuid, int, text, text, text, jsonb, uuid) to service_role;

-- ================================================================ storage (generated images)
insert into storage.buckets (id, name, public)
values ('generated-images', 'generated-images', false)
on conflict (id) do nothing;
-- Private bucket, no policies: only the server (service role) reads/writes via signed URLs.

-- ================================================================ seed data (editable by admins)
insert into public.plans
  (id, name, monthly_coins, price_eur_month, price_usd_month, price_eur_year, price_usd_year,
   history_limit, max_brands, can_favorite, can_export, can_calendar, can_brand_voice, features, sort)
values
 ('free','Free',100,0,0,0,0,20,0,false,false,false,false,
  '[{"en":"100 coins per month","pt":"100 moedas por mês","status":"live"},
    {"en":"Captions, hashtags, ideas, titles and video scripts","pt":"Legendas, hashtags, ideias, títulos e guiões de vídeo","status":"live"},
    {"en":"History of your last 20 creations","pt":"Histórico das últimas 20 criações","status":"live"}]', 0),
 ('pro','Pro',2000,1799,1900,17990,19000,0,1,true,true,true,true,
  '[{"en":"2,000 coins per month","pt":"2.000 moedas por mês","status":"live"},
    {"en":"All content tools: articles, ads, emails, SEO, calendars","pt":"Todas as ferramentas: artigos, anúncios, emails, SEO, calendários","status":"live"},
    {"en":"AI image generation (coin cost applies)","pt":"Geração de imagens com IA (custo em moedas)","status":"live"},
    {"en":"Full history, favorites and export","pt":"Histórico completo, favoritos e exportação","status":"live"},
    {"en":"Custom brand voice and content calendar","pt":"Voz da marca personalizada e calendário","status":"live"},
    {"en":"Priority processing","pt":"Processamento prioritário","status":"soon"}]', 1),
 ('business','Business',5000,3599,3900,35990,39000,0,10,true,true,true,true,
  '[{"en":"5,000 coins per month","pt":"5.000 moedas por mês","status":"live"},
    {"en":"Everything in Pro","pt":"Tudo o que existe no Pro","status":"live"},
    {"en":"Multiple brands and projects","pt":"Várias marcas e projetos","status":"live"},
    {"en":"Usage statistics","pt":"Estatísticas de utilização","status":"live"},
    {"en":"Team seats (up to 3 users)","pt":"Equipa (até 3 utilizadores)","status":"soon"},
    {"en":"Batch creation and collaboration tools","pt":"Criação em lote e colaboração","status":"soon"},
    {"en":"Priority support","pt":"Suporte prioritário","status":"soon"}]', 2)
on conflict (id) do nothing;

insert into public.tool_costs (tool, coins, enabled, min_plan, sort) values
 ('caption',2,true,'free',1),
 ('hashtags',1,true,'free',2),
 ('ideas',2,true,'free',3),
 ('script',5,true,'free',4),
 ('titles',1,true,'free',5),
 ('ad',3,true,'pro',6),
 ('email',3,true,'pro',7),
 ('product',2,true,'pro',8),
 ('seo',4,true,'pro',9),
 ('repurpose',4,true,'pro',10),
 ('blog',8,true,'pro',11),
 ('calendar',15,true,'pro',12),
 ('image',10,true,'pro',13),
 ('video',50,false,'pro',14)   -- disabled: needs a video provider (pending)
on conflict (tool) do nothing;

insert into public.coin_packages (name, coins, price_eur, price_usd, sort)
select * from (values
  ('Starter', 500, 499, 549, 1),
  ('Creator', 1500, 1299, 1399, 2),
  ('Studio', 4000, 2999, 3299, 3)
) as v(name, coins, price_eur, price_usd, sort)
where not exists (select 1 from public.coin_packages);
